using System.Drawing;
using System.Text.Json;

namespace DesktopPet;

public sealed record Frame(string File, int Ms, int FootX, int FootY);
public sealed record Clip(bool Loop, Frame[] Frames)
{
    public int Duration => Frames.Sum(frame => frame.Ms);

    public int IndexAt(long elapsed)
    {
        int duration = Duration;
        long phase = Loop ? elapsed % duration : Math.Min(elapsed, duration - 1);
        for (int i = 0; i < Frames.Length; i++)
        {
            if (phase < Frames[i].Ms) return i;
            phase -= Frames[i].Ms;
        }
        throw new InvalidOperationException("Invalid animation timing.");
    }
}

public sealed record Pack(string Name, int Scale, Dictionary<string, Clip> Clips)
{
    public static readonly string[] States = ["idle", "walk", "sit", "eat", "drink", "reaction", "yawn", "sleep", "wake"];
    public static readonly JsonSerializerOptions Json = new(JsonSerializerDefaults.Web) { WriteIndented = true };

    public void Validate()
    {
        if (string.IsNullOrWhiteSpace(Name) || Scale is < 50 or > 200 || Clips is null || !Clips.ContainsKey("idle"))
            throw new InvalidDataException("팩 이름, 크기(50~200%), idle 동작이 필요합니다.");
        foreach (var (state, clip) in Clips)
        {
            if (!States.Contains(state) || clip?.Frames is not { Length: > 0 and <= 256 })
                throw new InvalidDataException($"지원되지 않거나 비어 있는 동작: {state}");
            foreach (var frame in clip.Frames)
                if (frame is null || !IsImageName(frame.File) || frame.Ms is < 16 or > 60_000 ||
                    frame.FootX < 0 || frame.FootY < 0)
                    throw new InvalidDataException($"잘못된 프레임 파일, 시간(16~60000ms) 또는 기준점: {state}");
        }
    }

    private static bool IsImageName(string? name) =>
        !string.IsNullOrWhiteSpace(name) && !name.Any(c => c is '/' or '\\' or ':' || char.IsControl(c))
        && Path.GetExtension(name).Equals(".png", StringComparison.OrdinalIgnoreCase);
}

public sealed class Behavior
{
    private static readonly (string State, int Weight)[] Choices =
        [("walk", 6), ("sit", 4), ("eat", 3), ("drink", 3), ("reaction", 2), ("yawn", 2), ("sleep", 1)];
    private readonly Pack pack;
    private readonly Random random;
    private readonly Dictionary<string, long> cooldown = new();
    private long until;
    public long Started { get; private set; }
    public string State { get; private set; } = "idle";
    public int Direction { get; private set; } = 1;

    public Behavior(Pack pack, Random random, long now)
    {
        this.pack = pack;
        this.random = random;
        Enter("idle", now);
    }

    public void Tick(long now)
    {
        if (now < until) return;
        if (State != "idle")
        {
            string? follow = State switch { "yawn" => "sleep", "sleep" => "wake", _ => null };
            cooldown[State] = now + 10_000;
            Enter(follow is not null && pack.Clips.ContainsKey(follow) ? follow : "idle", now);
            return;
        }
        var available = Choices.Where(c => pack.Clips.ContainsKey(c.State) &&
            cooldown.GetValueOrDefault(c.State) <= now).ToArray();
        if (available.Length == 0) { Enter("idle", now); return; }
        int roll = random.Next(available.Sum(c => c.Weight));
        foreach (var item in available)
        {
            if (roll < item.Weight) { Enter(item.State, now); return; }
            roll -= item.Weight;
        }
    }

    private void Enter(string state, long now)
    {
        State = state;
        Started = now;
        if (state == "walk") Direction = random.Next(2) == 0 ? -1 : 1;
        int length = pack.Clips[state].Duration;
        until = now + (state switch
        {
            "idle" => Math.Max(length, random.Next(2500, 6501)),
            "walk" or "sit" or "sleep" when pack.Clips[state].Loop => length * ((6000 + length - 1) / length),
            _ => length
        });
    }

    public bool React(long now)
    {
        if (State != "idle" || !pack.Clips.ContainsKey("reaction") ||
            cooldown.GetValueOrDefault("reaction") > now) return false;
        Enter("reaction", now);
        return true;
    }
}

public static class Placement
{
    public static Point SpriteOffset(Point anchor, Point foot, int width, bool mirrored)
        => new(anchor.X - (mirrored ? width - foot.X : foot.X), anchor.Y - foot.Y);

    public static Point Clamp(Point pos, Size size, Rectangle area)
        => new(Math.Clamp(pos.X, area.Left, Math.Max(area.Left, area.Right - size.Width)),
               Math.Clamp(pos.Y, area.Top, Math.Max(area.Top, area.Bottom - size.Height)));
}
