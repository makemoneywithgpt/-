using DesktopPet;
using System.Drawing;

int passed = 0;
void Check(string name, bool result)
{
    if (!result) throw new Exception(name);
    Console.WriteLine($"PASS {name}");
    passed++;
}

var first = new Frame("first.png", 220, 80, 100);
var second = new Frame("second.png", 80, 75, 105);
var idle = new Clip(true, [first, second]);
var once = new Clip(false, [first, second]);
Check("variable frame timing, loop and one-shot hold", idle.IndexAt(219) == 0 && idle.IndexAt(220) == 1 &&
    idle.IndexAt(299) == 1 && idle.IndexAt(300) == 0 && once.IndexAt(400) == 1);
var none = new Pack("idle", 100, new() { ["idle"] = idle });
none.Validate();
var idleOnly = new Behavior(none, new Random(2), 0);
idleOnly.Tick(30_000);
Check("missing actions remain idle", idleOnly.State == "idle" && !idleOnly.React(30_000));
var full = new Pack("test", 100, new() { ["idle"] = idle, ["sleep"] = once, ["wake"] = once, ["reaction"] = once });
full.Validate();
var b = new Behavior(full, new Random(2), 0);
Check("reaction does not interrupt or reset clip", b.React(50) && !b.React(70) && b.Started == 50);
b.Tick(349);
Check("action holds until complete", b.State == "reaction");
b.Tick(350);
Check("reaction cooldown", b.State == "idle" && !b.React(351));
b.Tick(7000);
b.Tick(7300);
Check("sleep transitions to wake", b.State == "wake");
b.Tick(7600);
Check("wake returns to idle", b.State == "idle");
Check("bounds include negative-origin monitors", Placement.Clamp(new Point(-20, 900),
    new Size(100, 100), new Rectangle(-1600, 0, 1600, 900)) == new Point(-100, 800));
var anchor = new Point(110, 150);
Check("left and right feet align on same anchor",
    Placement.SpriteOffset(anchor, new Point(35, 120), 100, true) == new Point(45, 30) &&
    Placement.SpriteOffset(anchor, new Point(35, 120), 100, false) == new Point(75, 30));
try
{
    new Pack("bad", 100, new() { ["idle"] = new Clip(true, [first with { File = "../first.png" }]) }).Validate();
    throw new Exception("path traversal accepted");
}
catch (InvalidDataException) { Check("reject parent path", true); }
Console.WriteLine($"{passed} checks passed");
