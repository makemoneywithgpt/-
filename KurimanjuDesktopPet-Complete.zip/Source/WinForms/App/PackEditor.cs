using System.Diagnostics;
using System.Text.Json;

namespace DesktopPet;

internal sealed class PackEditor : Form
{
    private readonly string path;
    private readonly TextBox name = new() { Width = 170 };
    private readonly NumericUpDown scale = new() { Minimum = 50, Maximum = 200, Value = 100, Width = 65 };
    private readonly DataGridView rows = new() { Dock = DockStyle.Fill, AutoSizeColumnsMode = DataGridViewAutoSizeColumnsMode.Fill };
    private readonly PictureBox preview = new() { Height = 200, Dock = DockStyle.Bottom, SizeMode = PictureBoxSizeMode.CenterImage };
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 33 };
    private readonly Stopwatch clock = new();
    private Art? art;
    private Clip? clip;
    private int lastIndex = -1;

    public PackEditor(string path)
    {
        this.path = path;
        Text = "캐릭터 팩 편집";
        Width = 800;
        Height = 640;
        rows.Columns.Add(new DataGridViewComboBoxColumn { HeaderText = "동작", DataSource = Pack.States });
        rows.Columns.Add("File", "PNG 파일명");
        rows.Columns.Add("Ms", "표시 시간(ms)");
        rows.Columns.Add("X", "발 기준 X");
        rows.Columns.Add("Y", "발 기준 Y");
        rows.Columns.Add(new DataGridViewCheckBoxColumn { HeaderText = "반복" });
        var bar = new FlowLayoutPanel { Dock = DockStyle.Top, Height = 40 };
        bar.Controls.AddRange([new Label { Text = "팩 이름", AutoSize = true }, name,
            new Label { Text = "크기 %", AutoSize = true }, scale,
            Button("PNG 추가", AddImages), Button("위", () => MoveRow(-1)), Button("아래", () => MoveRow(1)),
            Button("선택 동작 재생", Preview), Button("저장", Save)]);
        Controls.Add(rows);
        Controls.Add(preview);
        Controls.Add(bar);
        name.Text = Path.GetFileNameWithoutExtension(path);
        if (File.Exists(path))
        {
            using var original = new Art(path);
            name.Text = original.Pack.Name;
            scale.Value = original.Pack.Scale;
            foreach (var (state, value) in original.Pack.Clips)
                foreach (var frame in value.Frames)
                    rows.Rows.Add(state, frame.File, frame.Ms, frame.FootX, frame.FootY, value.Loop);
        }
        timer.Tick += (_, _) => DrawPreview();
    }

    private Button Button(string title, Action click)
    {
        var button = new Button { Text = title, AutoSize = true };
        button.Click += (_, _) =>
        {
            try { click(); }
            catch (Exception error) { MessageBox.Show(this, error.Message, "캐릭터 팩"); }
        };
        return button;
    }

    private void AddImages()
    {
        using var picker = new OpenFileDialog { Filter = "PNG|*.png", Multiselect = true,
            InitialDirectory = Path.GetDirectoryName(path) };
        if (picker.ShowDialog(this) != DialogResult.OK) return;
        if (picker.FileNames.Any(file => !string.Equals(Path.GetDirectoryName(file), Path.GetDirectoryName(path),
            StringComparison.OrdinalIgnoreCase)))
            throw new InvalidDataException("PNG와 팩 JSON을 같은 폴더에 두세요.");
        foreach (string file in picker.FileNames.Order(StringComparer.OrdinalIgnoreCase))
        {
            using var image = Image.FromFile(file);
            rows.Rows.Add(rows.CurrentRow?.Cells[0].Value ?? "idle",
                Path.GetFileName(file), 220, image.Width / 2, image.Height, true);
        }
    }

    private void MoveRow(int step)
    {
        rows.EndEdit();
        var row = rows.CurrentRow;
        if (row is null || row.IsNewRow) return;
        int target = row.Index + step;
        if (target < 0 || target >= rows.NewRowIndex) return;
        var values = row.Cells.Cast<DataGridViewCell>().Select(cell => cell.Value).ToArray();
        rows.Rows.Remove(row);
        rows.Rows.Insert(target, values);
        rows.CurrentCell = rows.Rows[target].Cells[0];
    }

    private Pack ReadRows()
    {
        rows.EndEdit();
        var clips = rows.Rows.Cast<DataGridViewRow>().Where(row => !row.IsNewRow)
            .GroupBy(row => Convert.ToString(row.Cells[0].Value) ?? "");
        var result = new Dictionary<string, Clip>();
        foreach (var group in clips)
        {
            var modes = group.Select(row => row.Cells[5].Value is true).Distinct().ToArray();
            if (modes.Length != 1) throw new InvalidDataException($"{group.Key}의 반복 여부를 모든 행에서 같게 설정하세요.");
            int Number(DataGridViewRow row, int i) => int.Parse(Convert.ToString(row.Cells[i].Value) ?? "");
            result[group.Key] = new Clip(modes[0], group.Select(row => new Frame(
                Convert.ToString(row.Cells[1].Value) ?? "", Number(row, 2), Number(row, 3), Number(row, 4))).ToArray());
        }
        return new Pack(name.Text, (int)scale.Value, result);
    }

    private void Preview()
    {
        string state = Convert.ToString(rows.CurrentRow?.Cells[0].Value) ?? "idle";
        var draft = new Art(path, ReadRows());
        if (!draft.Pack.Clips.TryGetValue(state, out var selected))
        {
            draft.Dispose();
            return;
        }
        art?.Dispose();
        art = draft;
        clip = selected;
        lastIndex = -1;
        clock.Restart();
        DrawPreview();
        timer.Start();
    }

    private void DrawPreview()
    {
        var current = art!;
        int index = clip!.IndexAt(clock.ElapsedMilliseconds);
        if (!clip.Loop && clock.ElapsedMilliseconds >= clip.Duration) timer.Stop();
        if (index == lastIndex) return;
        lastIndex = index;
        var frame = clip.Frames[index];
        var png = current.Images[frame.File];
        double fit = Math.Min(Math.Min(360.0 / current.Canvas.Width, 200.0 / current.Canvas.Height),
            current.Pack.Scale / 100.0);
        int Px(int value) => (int)Math.Round(value * fit);
        var canvas = new Bitmap(Math.Max(1, Px(current.Canvas.Width)), Math.Max(1, Px(current.Canvas.Height)));
        using (var graphics = Graphics.FromImage(canvas))
            graphics.DrawImage(png, Px(current.Anchor.X - frame.FootX), Px(current.Anchor.Y - frame.FootY),
                Math.Max(1, Px(png.Width)), Math.Max(1, Px(png.Height)));
        var previous = preview.Image;
        preview.Image = canvas;
        previous?.Dispose();
    }

    private void Save()
    {
        using var checkedArt = new Art(path, ReadRows());
        string staged = path + "." + Guid.NewGuid().ToString("N") + ".tmp";
        try
        {
            File.WriteAllText(staged, JsonSerializer.Serialize(checkedArt.Pack, Pack.Json));
            File.Move(staged, path, overwrite: true);
        }
        finally { File.Delete(staged); }
        DialogResult = DialogResult.OK;
        Close();
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing) { timer.Dispose(); art?.Dispose(); preview.Image?.Dispose(); }
        base.Dispose(disposing);
    }
}
