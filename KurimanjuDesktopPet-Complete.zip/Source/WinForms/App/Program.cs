namespace DesktopPet;

internal static class Program
{
    [STAThread]
    private static void Main()
    {
        Application.SetHighDpiMode(HighDpiMode.PerMonitorV2);
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        using var app = new PetApplication();
        Application.Run(app);
    }
}

internal sealed class PetApplication : ApplicationContext
{
    private readonly NotifyIcon tray;
    private readonly ContextMenuStrip menu = new();
    private readonly string config = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData),
        "KurimanjuDesktopPet", "pack-path.txt");
    private PetWindow? window;
    private Art? art;
    private string? packPath;

    public PetApplication()
    {
        menu.Items.Add("캐릭터 팩 열기", null, (_, _) => Choose(false));
        menu.Items.Add("새 캐릭터 팩", null, (_, _) => Choose(true));
        menu.Items.Add("현재 팩 편집", null, (_, _) => Edit());
        var sizes = new ToolStripMenuItem("표시 크기");
        foreach (int scale in new[] { 75, 100, 125, 150 })
            sizes.DropDownItems.Add($"{scale}%", null, (_, _) => window?.SetScale(scale));
        menu.Items.Add(sizes);
        menu.Items.Add("지원 동작 확인", null, (_, _) => ShowStatus());
        menu.Items.Add("종료", null, (_, _) => ExitThread());
        tray = new NotifyIcon { Text = "쿠리만쥬 데스크탑 펫", Icon = SystemIcons.Application,
            ContextMenuStrip = menu, Visible = true };
        tray.DoubleClick += (_, _) => Choose(false);
        if (File.Exists(config)) Try(() => Load(File.ReadAllText(config)));
        else tray.ShowBalloonTip(4000, "캐릭터 팩 필요", "트레이 아이콘을 우클릭해 PNG 팩을 열거나 만드세요.", ToolTipIcon.Info);
    }

    private void Choose(bool create) => Try(() =>
    {
        using FileDialog picker = create
            ? new SaveFileDialog { Filter = "캐릭터 팩|*.json", FileName = "pet.json", OverwritePrompt = true }
            : new OpenFileDialog { Filter = "캐릭터 팩|*.json" };
        if (picker.ShowDialog() != DialogResult.OK) return;
        if (create)
        {
            using var editor = new PackEditor(picker.FileName);
            if (editor.ShowDialog() != DialogResult.OK) return;
        }
        Load(picker.FileName);
    });

    private void Edit() => Try(() =>
    {
        if (packPath is null) { Choose(true); return; }
        using var editor = new PackEditor(packPath);
        if (editor.ShowDialog() == DialogResult.OK) Load(packPath);
    });

    private void Load(string path)
    {
        var next = new Art(path);
        var candidate = new PetWindow(next) { ContextMenuStrip = menu };
        try { candidate.Show(); }
        catch { candidate.Dispose(); next.Dispose(); throw; }
        window?.Dispose();
        art?.Dispose();
        window = candidate;
        art = next;
        packPath = path;
        Directory.CreateDirectory(Path.GetDirectoryName(config)!);
        File.WriteAllText(config, path);
    }

    private void ShowStatus()
    {
        var missing = Pack.States.Where(state => art is null || !art.Pack.Clips.ContainsKey(state));
        MessageBox.Show("현재 팩: " + (art?.Pack.Name ?? "없음") + "\n누락 동작: " + string.Join(", ", missing),
            "캐릭터 팩 상태");
    }

    private static void Try(Action run)
    {
        try { run(); }
        catch (Exception error) { MessageBox.Show(error.Message, "쿠리만쥬 데스크탑 펫"); }
    }

    protected override void Dispose(bool disposing)
    {
        if (disposing)
        {
            window?.Dispose();
            art?.Dispose();
            tray.Dispose();
            menu.Dispose();
        }
        base.Dispose(disposing);
    }
}
