using System.Diagnostics;

namespace DesktopPet;

internal sealed class PetWindow : Form
{
    private readonly Art art;
    private readonly Layer layer = new();
    private readonly System.Windows.Forms.Timer timer = new() { Interval = 33 };
    private readonly Stopwatch clock = Stopwatch.StartNew();
    private readonly Behavior behavior;
    private Point dragStart, windowStart;
    private bool held, dragged, refresh = true;
    private Frame? displayed;
    private int orientation, scale = 100, direction = 1;
    private long walkStarted = -1;
    private double horizontal;
    private long tickAt;

    public PetWindow(Art art)
    {
        this.art = art;
        behavior = new Behavior(art.Pack, Random.Shared, 0);
        FormBorderStyle = FormBorderStyle.None;
        AutoScaleMode = AutoScaleMode.None;
        StartPosition = FormStartPosition.Manual;
        ShowInTaskbar = false;
        TopMost = true;
        var area = Screen.PrimaryScreen!.WorkingArea;
        Location = new Point(area.Right - 160, area.Bottom - 160);
        timer.Tick += (_, _) => Draw();
    }

    protected override CreateParams CreateParams
    {
        get { var p = base.CreateParams; p.ExStyle |= 0x80000 | 0x80 | 0x08000000; return p; }
    }
    protected override bool ShowWithoutActivation => true;
    protected override void OnShown(EventArgs e) { base.OnShown(e); Draw(); timer.Start(); }
    protected override void OnDpiChanged(DpiChangedEventArgs e)
    { base.OnDpiChanged(e); refresh = true; }
    public void SetScale(int percent) { scale = percent; refresh = true; }

    private void Draw()
    {
        long now = clock.ElapsedMilliseconds;
        long elapsed = Math.Min(now - tickAt, 100);
        tickAt = now;
        if (!held) behavior.Tick(now);

        var clip = art.Pack.Clips[behavior.State];
        var frame = clip.Frames[clip.IndexAt(now - behavior.Started)];
        var icon = art.Images[frame.File];
        var area = Screen.FromRectangle(Bounds).WorkingArea;
        double factor = art.Pack.Scale * scale / 10_000.0 * DeviceDpi / 96.0;
        factor = Math.Min(factor, Math.Min((double)area.Width / art.Canvas.Width, (double)area.Height / art.Canvas.Height));
        int Pixels(int value) => (int)Math.Round(value * factor);
        var size = new Size(Math.Max(1, Pixels(art.Canvas.Width)), Math.Max(1, Pixels(art.Canvas.Height)));
        var position = Location;
        if (behavior.State == "walk" && behavior.Started != walkStarted)
        {
            walkStarted = behavior.Started;
            direction = behavior.Direction;
            horizontal = 0;
        }
        if (behavior.State == "walk" && !held)
        {
            horizontal += direction * elapsed * DeviceDpi / 96.0 * 0.035;
            int step = (int)horizontal;
            horizontal -= step;
            position.X += step;
            if (position.X < area.Left || position.X + size.Width > area.Right)
            {
                direction = -direction;
                horizontal = 0;
            }
        }
        position = Placement.Clamp(position, size, area);
        bool redraw = refresh || frame != displayed || orientation != direction || Size != size;
        if (!redraw && position == Location) return;
        var offset = Placement.SpriteOffset(art.Anchor, new Point(frame.FootX, frame.FootY), icon.Width, direction < 0);
        var destination = new Rectangle(Pixels(offset.X), Pixels(offset.Y),
            Math.Max(1, Pixels(icon.Width)), Math.Max(1, Pixels(icon.Height)));
        using var mirrored = direction < 0 && redraw ? new Bitmap(icon) : null;
        mirrored?.RotateFlip(RotateFlipType.RotateNoneFlipX);
        layer.Present(Handle, mirrored ?? icon, position, size, destination, redraw);
        displayed = frame;
        orientation = direction;
        refresh = false;
    }

    protected override void OnMouseDown(MouseEventArgs e)
    {
        base.OnMouseDown(e);
        if (e.Button != MouseButtons.Left) return;
        held = Capture = true;
        dragged = false;
        dragStart = Cursor.Position;
        windowStart = Location;
    }

    protected override void OnMouseMove(MouseEventArgs e)
    {
        base.OnMouseMove(e);
        if (!held) return;
        var pointer = Cursor.Position;
        int dx = pointer.X - dragStart.X, dy = pointer.Y - dragStart.Y;
        if (Math.Abs(dx) + Math.Abs(dy) < 4 && !dragged) return;
        dragged = true;
        Location = Placement.Clamp(new Point(windowStart.X + dx, windowStart.Y + dy),
            Size, Screen.FromPoint(pointer).WorkingArea);
    }

    protected override void OnMouseUp(MouseEventArgs e)
    {
        base.OnMouseUp(e);
        if (e.Button != MouseButtons.Left || !held) return;
        held = Capture = false;
        if (!dragged) behavior.React(clock.ElapsedMilliseconds);
    }

    protected override void OnMouseCaptureChanged(EventArgs e)
    { base.OnMouseCaptureChanged(e); if (!Capture) held = false; }

    protected override void Dispose(bool disposing)
    {
        if (disposing) { timer.Dispose(); layer.Dispose(); }
        base.Dispose(disposing);
    }
}
