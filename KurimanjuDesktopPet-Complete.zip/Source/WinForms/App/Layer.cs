using System.Drawing.Imaging;
using System.Runtime.InteropServices;

namespace DesktopPet;

internal sealed class Layer : IDisposable
{
    [StructLayout(LayoutKind.Sequential)]
    private record struct NativePoint(int X, int Y);
    [StructLayout(LayoutKind.Sequential)]
    private record struct NativeSize(int Width, int Height);
    [StructLayout(LayoutKind.Sequential)]
    private record struct Blend(byte Op, byte Flags, byte Opacity, byte AlphaFormat);
    [StructLayout(LayoutKind.Sequential)]
    private struct BitmapInfo
    {
        public uint Size;
        public int Width, Height;
        public ushort Planes, Bits;
        public uint Compression, ImageSize;
        public int XResolution, YResolution;
        public uint Used, Important, Color;
    }
    [DllImport("gdi32.dll")] private static extern IntPtr CreateCompatibleDC(IntPtr dc);
    [DllImport("gdi32.dll")] private static extern bool DeleteDC(IntPtr dc);
    [DllImport("gdi32.dll")] private static extern IntPtr SelectObject(IntPtr dc, IntPtr obj);
    [DllImport("gdi32.dll")] private static extern bool DeleteObject(IntPtr obj);
    [DllImport("gdi32.dll")] private static extern IntPtr CreateDIBSection(IntPtr dc, ref BitmapInfo info, uint usage, out IntPtr pixels, IntPtr section, uint offset);
    [DllImport("user32.dll", SetLastError = true)] private static extern bool UpdateLayeredWindow(IntPtr hwnd, IntPtr dst, ref NativePoint pos,
        ref NativeSize size, IntPtr src, ref NativePoint origin, uint key, ref Blend blend, uint flags);

    private IntPtr dc, dib, previous;
    private Bitmap? canvas;
    private Size size;

    public void Present(IntPtr window, Bitmap sprite, Point position, Size viewport, Rectangle destination, bool redraw)
    {
        if (canvas is null || viewport != size)
        {
            Dispose();
            size = viewport;
            dc = CreateCompatibleDC(IntPtr.Zero);
            var info = new BitmapInfo { Size = 40, Width = size.Width, Height = -size.Height, Planes = 1, Bits = 32 };
            dib = CreateDIBSection(dc, ref info, 0, out var pixels, IntPtr.Zero, 0);
            if (dc == IntPtr.Zero || dib == IntPtr.Zero) throw new InvalidOperationException("투명 렌더링 표면을 만들 수 없습니다.");
            previous = SelectObject(dc, dib);
            canvas = new Bitmap(size.Width, size.Height, size.Width * 4, PixelFormat.Format32bppPArgb, pixels);
            redraw = true;
        }
        if (redraw)
        {
            using var graphics = Graphics.FromImage(canvas);
            graphics.Clear(Color.Transparent);
            graphics.InterpolationMode = System.Drawing.Drawing2D.InterpolationMode.HighQualityBicubic;
            graphics.DrawImage(sprite, destination);
        }
        var point = new NativePoint(position.X, position.Y);
        var dimensions = new NativeSize(size.Width, size.Height);
        var origin = new NativePoint(0, 0);
        var blend = new Blend(0, 0, 255, 1);
        if (!UpdateLayeredWindow(window, IntPtr.Zero, ref point, ref dimensions, dc, ref origin, 0, ref blend, 2))
            throw new System.ComponentModel.Win32Exception(Marshal.GetLastWin32Error());
    }

    public void Dispose()
    {
        canvas?.Dispose();
        canvas = null;
        if (previous != IntPtr.Zero) SelectObject(dc, previous);
        if (dib != IntPtr.Zero) DeleteObject(dib);
        if (dc != IntPtr.Zero) DeleteDC(dc);
        dc = dib = previous = IntPtr.Zero;
    }
}
