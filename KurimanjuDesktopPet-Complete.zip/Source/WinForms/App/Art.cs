using System.Drawing.Imaging;
using System.Text.Json;

namespace DesktopPet;

internal sealed class Art : IDisposable
{
    public Pack Pack { get; }
    public Dictionary<string, Bitmap> Images { get; } = new(StringComparer.OrdinalIgnoreCase);
    public Size Canvas { get; private set; }
    public Point Anchor { get; private set; }

    public Art(string path, Pack? draft = null)
    {
        Pack = draft ?? JsonSerializer.Deserialize<Pack>(File.ReadAllText(path), Pack.Json)
            ?? throw new InvalidDataException("빈 캐릭터 팩입니다.");
        Pack.Validate();
        var dir = Path.GetDirectoryName(path)!;
        int left = 0, top = 0, right = 0, bottom = 0;
        long totalPixels = 0;
        try
        {
            foreach (var frame in Pack.Clips.Values.SelectMany(clip => clip.Frames))
            {
                if (!Images.TryGetValue(frame.File, out var sprite))
                {
                    using var loaded = Image.FromFile(Path.Combine(dir, frame.File));
                    if (loaded.RawFormat.Guid != ImageFormat.Png.Guid || loaded.Width > 1024 || loaded.Height > 1024 ||
                        (totalPixels += (long)loaded.Width * loaded.Height) > 16_777_216)
                        throw new InvalidDataException($"PNG 크기 또는 팩 이미지 용량을 확인하세요: {frame.File}");
                    sprite = new Bitmap(loaded);
                    Images.Add(frame.File, sprite);
                    bool transparent = false, visible = false;
                    for (int y = 0; y < sprite.Height && !(transparent && visible); y++)
                        for (int x = 0; x < sprite.Width && !(transparent && visible); x++)
                        {
                            byte alpha = sprite.GetPixel(x, y).A;
                            transparent |= alpha == 0;
                            visible |= alpha > 0;
                        }
                    if (!transparent || !visible)
                        throw new InvalidDataException($"캐릭터와 실제 투명 영역이 모두 필요합니다: {frame.File}");
                }
                if (frame.FootX > sprite.Width || frame.FootY > sprite.Height)
                    throw new InvalidDataException($"발 기준점이 프레임 밖입니다: {frame.File}");
                left = Math.Max(left, frame.FootX);
                top = Math.Max(top, frame.FootY);
                right = Math.Max(right, sprite.Width - frame.FootX);
                bottom = Math.Max(bottom, sprite.Height - frame.FootY);
            }
            // Include both orientations so a turn never shifts the foot anchor.
            left = right = Math.Max(left, right);
            Canvas = new Size(left + right, top + bottom);
            Anchor = new Point(left, top);
        }
        catch { Dispose(); throw; }
    }

    public void Dispose()
    {
        foreach (var bitmap in Images.Values) bitmap.Dispose();
        Images.Clear();
    }
}
