# 쿠리만쥬 데스크탑 펫

Windows 10/11 x64용 독립 WinForms 개발 빌드입니다. Windows에서 `KurimanjuDesktopPet.exe`를 더블클릭하면 작업 표시줄 오른쪽에 트레이 아이콘이 생깁니다. 아이콘이 숨겨져 있으면 **숨겨진 아이콘 표시(⌃)**를 열어 보세요. 캐릭터 팩을 아직 등록하지 않았다면 트레이만 시작합니다.

## 팩을 만들고 사용하기

1. 사용 권한이 있는 투명 PNG 프레임을 한 폴더에 둡니다.
2. 트레이 아이콘을 우클릭해 **새 캐릭터 팩**을 선택하고 그 폴더에 `pet.json`을 지정합니다.
3. **PNG 추가**로 프레임을 넣습니다. 표에서 동작 이름, 밀리초, 발 기준점 X/Y, 반복 여부를 지정한 뒤 **위/아래**로 순서를 조절합니다. 같은 동작의 반복 여부는 모든 행에서 같아야 합니다.
4. **선택 동작 재생**에서 미리 보고 **저장**합니다. 이미 JSON 팩이 있으면 **캐릭터 팩 열기**를 사용합니다.
5. 캐릭터에 마우스를 올리고 끌면 이동합니다. 트레이에서 크기, 지원 동작, 종료를 선택할 수 있습니다. 왼쪽 클릭 반응은 `reaction`이 있을 때 대기 중에만 실행합니다.

팩 JSON과 PNG는 같은 폴더에 두세요. 앱은 마지막으로 연 JSON 경로를 사용자 로컬 설정에 저장합니다. 단일 EXE에 .NET 런타임을 포함했습니다.

## 동작 자료 규격

PNG의 긴 변은 1024px 이하이고, 유효한 전경과 알파 0인 배경 픽셀이 있어야 합니다. 같은 캐릭터 모션은 256×256 정도의 공통 작업 캔버스, 잘리지 않은 전신, 동일한 발 기준점, 일정한 머리 크기를 권장합니다. `footX`와 `footY`는 PNG의 왼쪽 위에서 잰 픽셀 위치입니다. 모든 동작을 한 번에 준비할 필요는 없습니다.

| 동작 | 필요한 프레임 |
| --- | --- |
| idle | 전신 정면 정지 자세 한 장. 검수된 눈깜빡임이 있으면 추가 |
| walk | 같은 배율의 보행 주기 전신 PNG. 발이 바닥에 닿는 지점 포함 |
| sit / eat / drink | 시작 자세와 본동작, 입·소품이 보이는 종료 자세 |
| reaction / yawn | 원본 표정 변화와 복귀 프레임 |
| sleep / wake | 잠든 자세와 눈을 뜨고 돌아오는 구간 |

시범 JSON 형식입니다. PNG는 별도로 준비해야 합니다.

```json
{
  "name": "내 캐릭터",
  "scale": 100,
  "clips": {
    "idle": {
      "loop": true,
      "frames": [{"file":"idle.png","ms":1000,"footX":128,"footY":224}]
    }
  }
}
```

## 개발 및 검증

```bat
dotnet run --project Checks/Checks.csproj -c Release
dotnet publish App/App.csproj -c Release -r win-x64 --self-contained -p:PublishSingleFile=true -p:IncludeNativeLibrariesForSelfExtract=true -p:EnableCompressionInSingleFile=true -p:DebugType=None -o publish
```

자동 검사 10개에서 가변 지속 시간, 반복·종료, 누락 동작 처리, 재발동 제한, 상태 전환, 발 기준점, 화면 제한 로직을 확인했습니다. Linux에서 Windows x64로 크로스 빌드했습니다. 실제 Windows의 트레이, 투명 영역 클릭 통과, DPI와 다중 모니터, 드래그, CPU 점유율, 캐릭터 팩 실재생은 실기기 검증 항목입니다.

## 참고 자료 검토

- 식사 GIF 20프레임과 음료 GIF 35프레임은 표정과 소품 타이밍 참고용입니다. 국물 GIF는 정지 프레임 한 장입니다. 세 자료 모두 배경이 있고 전신 자세가 잘려 있습니다.
- 식사 초안은 알파 투명도가 있는 443×443 단일 그림입니다. 순서 있는 전신 식사 프레임을 만들 수 없어 배포 팩에 포함하지 않았습니다.
- 뽀링 압축 내부 EXE는 실행하지 않았습니다. 프레임 시트와 지침의 33ms 갱신, 220ms 기본 프레임을 참고했습니다.
- VPet의 동작과 모드 분리, BongoCat의 입력 반응 구조를 공개 README에서 확인했습니다. 두 코드 저장소에서 Apache-2.0 라이선스를 확인했습니다. Shimeji 계열 원본 코드와 라이선스는 이 환경에서 접속에 실패해 미확인입니다. 구현은 독립 작성했고 참고 코드나 이미지는 배포물에 넣지 않았습니다.
  [VPet](https://github.com/LorisYounger/VPet) · [BongoCat](https://github.com/ayangweb/BongoCat) · [Shimeji-ee](https://kilkakon.com/shimeji/)

카운트다운과 전역 키 감지는 이 그래픽 검증 빌드의 범위에서 보류했습니다.
